import { useState } from 'react'
import type { PageId } from '@/types'

// ── Types ────────────────────────────────────────────────────────────────────

type ContentType = 'Статья' | 'Кейс' | 'Новость'
type ContentStatus = 'published' | 'draft' | 'scheduled'

interface ContentItem {
  title: string
  type: ContentType
  status: ContentStatus
  author: string
  date: string
}

interface SeoCheck {
  label: string
  state: 'ok' | 'warn' | 'error'
}

interface ScheduledItem {
  title: string
  type: ContentType
  date: string
  dateLabel: string
}

// ── Mock data ────────────────────────────────────────────────────────────────

const recentContent: ContentItem[] = [
  { title: 'Как Telegram-бот увеличил выручку на 40%', type: 'Статья', status: 'published', author: 'Е. Морозова', date: '28 июл' },
  { title: 'Кейс: Додо Пицца — рост заказов через бот', type: 'Кейс', status: 'published', author: 'И. Козлов', date: '25 июл' },
  { title: 'CRM-интеграция для ресторанного бизнеса', type: 'Статья', status: 'draft', author: 'М. Сидорова', date: '24 июл' },
  { title: 'Открытие офиса в Санкт-Петербурге', type: 'Новость', status: 'published', author: 'А. Данилов', date: '20 июл' },
  { title: 'Мобильное приложение для доставки еды', type: 'Статья', status: 'scheduled', author: 'Е. Морозова', date: '5 авг' },
  { title: 'Интеграция с Яндекс.Едой и Delivery Club', type: 'Статья', status: 'published', author: 'Е. Морозова', date: '15 июл' },
]

const seoChecks: SeoCheck[] = [
  { label: 'robots.txt настроен', state: 'ok' },
  { label: 'sitemap.xml актуален', state: 'ok' },
  { label: 'SSL-сертификат действителен', state: 'ok' },
  { label: 'Опубликованные страницы индексируются', state: 'ok' },
  { label: '8 изображений без ALT-текста', state: 'warn' },
  { label: '2 страницы без Meta Description', state: 'warn' },
  { label: '1 битая ссылка (404)', state: 'error' },
]

const scheduledItems: ScheduledItem[] = [
  { title: 'CRM для доставки ресторанов', type: 'Статья', date: '1 авг 2026', dateLabel: 'Сегодня' },
  { title: 'Додо Пицца: рост заказов через бот', type: 'Кейс', date: '3 авг 2026', dateLabel: '3 августа' },
  { title: 'Интеграция MAX', type: 'Новость', date: '5 авг 2026', dateLabel: '5 августа' },
  { title: 'MAX-бот для ресторана: возможности', type: 'Статья', date: '7 авг 2026', dateLabel: '7 августа' },
]

// ── Status styles ─────────────────────────────────────────────────────────────

const STATUS_STYLES: Record<ContentStatus, { label: string; bg: string; text: string }> = {
  published: { label: 'Опубликовано', bg: 'bg-emerald-50', text: 'text-emerald-700' },
  draft: { label: 'Черновик', bg: 'bg-slate-100', text: 'text-slate-500' },
  scheduled: { label: 'Запланировано', bg: 'bg-cyan-50', text: 'text-cyan-700' },
}

const TYPE_STYLES: Record<ContentType, string> = {
  'Статья': 'bg-blue-50 text-blue-700',
  'Кейс': 'bg-violet-50 text-violet-700',
  'Новость': 'bg-amber-50 text-amber-700',
}

const SEO_STATE_ICON: Record<SeoCheck['state'], { icon: string; cls: string }> = {
  ok: { icon: '●', cls: 'text-emerald-500' },
  warn: { icon: '●', cls: 'text-amber-400' },
  error: { icon: '●', cls: 'text-red-500' },
}

type ContentFilter = 'all' | ContentType

const CONTENT_FILTERS: { id: ContentFilter; label: string }[] = [
  { id: 'all', label: 'Все' },
  { id: 'Статья', label: 'Статьи' },
  { id: 'Кейс', label: 'Кейсы' },
  { id: 'Новость', label: 'Новости' },
]

// ── Main component ────────────────────────────────────────────────────────────

export default function Dashboard({ onNavigate }: { onNavigate: (page: PageId) => void }) {
  const [contentFilter, setContentFilter] = useState<ContentFilter>('all')

  const filteredContent = recentContent.filter(
    item => contentFilter === 'all' || item.type === contentFilter
  )

  const seoOkCount = seoChecks.filter(c => c.state === 'ok').length
  const seoPct = Math.round((seoOkCount / seoChecks.length) * 100)

  return (
    <div className="p-7 max-w-6xl mx-auto space-y-6">

      {/* Header + Quick actions */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Добро пожаловать 👋</h1>
        <p className="text-sm text-slate-400 mt-1">Сегодня 1 августа 2026 · gastronavt.ru</p>

        {/* Quick actions */}
        <div className="flex items-center gap-2 mt-5 flex-wrap">
          <QuickAction
            icon={
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
            }
            label="Новая статья"
            primary
            onClick={() => onNavigate('content')}
          />
          <QuickAction
            icon={<span className="text-sm">📚</span>}
            label="Новый кейс"
            onClick={() => onNavigate('content')}
          />
          <QuickAction
            icon={<span className="text-sm">📰</span>}
            label="Новость"
            onClick={() => onNavigate('content')}
          />
          <QuickAction
            icon={
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            }
            label="Контент-план"
            onClick={() => onNavigate('content-plan')}
          />
        </div>
      </div>

      {/* KPI cards – 4 cards */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard
          label="Посетителей сегодня"
          value="3 102"
          change="+12% вчера"
          positive
          color="text-blue-600 bg-blue-50"
          icon={
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
            </svg>
          }
        />
        <StatCard
          label="Органический трафик"
          value="68 420"
          change="+8% за месяц"
          positive
          color="text-violet-600 bg-violet-50"
          icon={
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
          }
        />
        <StatCard
          label="Опубликовано материалов"
          value="84"
          change="3 черновика"
          positive={null}
          color="text-cyan-600 bg-cyan-50"
          icon={
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
            </svg>
          }
        />
        <StatCard
          label="SEO сайта"
          value="94%"
          change="+2% за неделю"
          positive
          color="text-emerald-600 bg-emerald-50"
          icon={
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
          }
        />
      </div>

      {/* Main 2-column grid */}
      <div className="grid grid-cols-3 gap-5">

        {/* Recent content – 2 cols */}
        <div className="col-span-2 bg-white rounded-xl border border-slate-200">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <h2 className="text-sm font-semibold text-slate-900">Последний контент</h2>
            <button onClick={() => onNavigate('content')} className="text-xs text-blue-600 hover:text-blue-700 cursor-pointer transition-colors">
              Все материалы →
            </button>
          </div>

          {/* Filter tabs */}
          <div className="flex gap-0.5 px-5 pt-3 pb-0">
            {CONTENT_FILTERS.map(f => (
              <button
                key={f.id}
                onClick={() => setContentFilter(f.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-colors ${
                  contentFilter === f.id ? 'bg-blue-50 text-blue-700' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="divide-y divide-slate-100 mt-2">
            {filteredContent.map((item, i) => {
              const s = STATUS_STYLES[item.status]
              return (
                <div key={i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-800 truncate">{item.title}</div>
                    <div className="text-xs text-slate-400 mt-0.5">{item.author} · {item.date}</div>
                  </div>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-md flex-shrink-0 ${TYPE_STYLES[item.type]}`}>{item.type}</span>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-md flex-shrink-0 ${s.bg} ${s.text}`}>{s.label}</span>
                </div>
              )
            })}
            {filteredContent.length === 0 && (
              <div className="px-5 py-8 text-center text-xs text-slate-400">Нет материалов</div>
            )}
          </div>
        </div>

        {/* SEO health – 1 col */}
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <h2 className="text-sm font-semibold text-slate-900">Состояние SEO</h2>
            <button onClick={() => onNavigate('seo')} className="text-xs text-blue-600 hover:text-blue-700 cursor-pointer transition-colors">
              Открыть SEO →
            </button>
          </div>

          {/* Health bar */}
          <div className="px-5 pt-4 pb-3">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs text-slate-500">Общее здоровье сайта</span>
              <span className={`text-sm font-bold ${seoPct >= 80 ? 'text-emerald-600' : seoPct >= 60 ? 'text-amber-500' : 'text-red-500'}`}>{seoPct}%</span>
            </div>
            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${seoPct >= 80 ? 'bg-emerald-500' : seoPct >= 60 ? 'bg-amber-400' : 'bg-red-500'}`}
                style={{ width: `${seoPct}%` }}
              />
            </div>
          </div>

          <div className="px-5 pb-5 space-y-2.5">
            {seoChecks.map((check, i) => {
              const st = SEO_STATE_ICON[check.state]
              return (
                <div key={i} className="flex items-start gap-2.5 text-sm">
                  <span className={`text-xs mt-0.5 flex-shrink-0 ${st.cls}`}>{st.icon}</span>
                  <span className={check.state === 'error' ? 'text-red-600' : check.state === 'warn' ? 'text-amber-700' : 'text-slate-600'}>
                    {check.label}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Content plan */}
      <div className="bg-white rounded-xl border border-slate-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 className="text-sm font-semibold text-slate-900">Контент-план</h2>
          <button onClick={() => onNavigate('content-plan')} className="text-xs text-blue-600 hover:text-blue-700 cursor-pointer transition-colors">
            Открыть контент-план →
          </button>
        </div>
        <div className="divide-y divide-slate-100">
          {scheduledItems.map((item, i) => (
            <div key={i} className="flex items-center gap-5 px-5 py-3.5 hover:bg-slate-50 transition-colors">
              <div className="w-20 flex-shrink-0">
                <span className={`text-xs font-semibold ${item.dateLabel === 'Сегодня' ? 'text-blue-600' : 'text-slate-400'}`}>
                  {item.dateLabel}
                </span>
              </div>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-md flex-shrink-0 ${TYPE_STYLES[item.type]}`}>{item.type}</span>
              <span className="text-sm font-medium text-slate-800 flex-1 min-w-0 truncate">{item.title}</span>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-md flex-shrink-0 ${STATUS_STYLES['scheduled'].bg} ${STATUS_STYLES['scheduled'].text}`}>
                Запланировано
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  )
}

// ── Sub-components ────────────────────────────────────────────────────────────

function StatCard({
  label, value, change, positive, color, icon
}: {
  label: string
  value: string
  change: string
  positive: boolean | null
  color: string
  icon: React.ReactNode
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-sm transition-shadow">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color}`}>
        {icon}
      </div>
      <div className="text-2xl font-bold text-slate-900 tracking-tight leading-none mb-1.5">{value}</div>
      <div className="text-xs text-slate-500 leading-snug mb-1">{label}</div>
      <div className={`text-xs font-medium ${positive === true ? 'text-emerald-600' : positive === false ? 'text-red-500' : 'text-slate-400'}`}>
        {change}
      </div>
    </div>
  )
}

function QuickAction({
  icon, label, primary = false, onClick
}: {
  icon: React.ReactNode
  label: string
  primary?: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 text-sm font-medium px-4 py-2 rounded-lg cursor-pointer transition-colors ${
        primary
          ? 'bg-blue-600 hover:bg-blue-700 text-white'
          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-slate-300'
      }`}
    >
      {icon}
      {label}
    </button>
  )
}
