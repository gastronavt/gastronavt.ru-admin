import { useState } from 'react'
import { Badge, Button, Input, Select, Drawer, FormField, TextArea } from '@/components/ui'

type ContentTab = 'articles' | 'cases' | 'news' | 'pages'
type Status = 'published' | 'draft' | 'scheduled'

const tabDef: { id: ContentTab; label: string }[] = [
  { id: 'articles', label: 'Статьи' },
  { id: 'cases', label: 'Кейсы' },
  { id: 'news', label: 'Новости' },
  { id: 'pages', label: 'Страницы' },
]

const articles = [
  { id: 1, title: 'Как Telegram-бот увеличил выручку ресторана на 40%', slug: 'telegram-bot-vyruchka-40', author: 'Екатерина Морозова', category: 'Telegram-боты', status: 'published' as Status, date: '28 июл 2026', views: 4820, seo: 94 },
  { id: 2, title: 'CRM-интеграция для ресторанного бизнеса: полное руководство', slug: 'crm-integraciya-restoran', author: 'Иван Козлов', category: 'CRM', status: 'published' as Status, date: '25 июл 2026', views: 3610, seo: 88 },
  { id: 3, title: 'Мобильное приложение для доставки еды: зачем и как', slug: 'mobilnoe-prilozhenie-dostavka', author: 'Мария Сидорова', category: 'Приложения', status: 'published' as Status, date: '22 июл 2026', views: 2980, seo: 82 },
  { id: 4, title: '5 ошибок при запуске программы лояльности', slug: '5-oshibok-loyalnost', author: 'Алексей Данилов', category: 'Лояльность', status: 'draft' as Status, date: '—', views: 0, seo: 61 },
  { id: 5, title: 'MAX-бот для ресторана: возможности и настройка', slug: 'max-bot-restoran', author: 'Дмитрий Петров', category: 'MAX-боты', status: 'scheduled' as Status, date: '5 авг 2026', views: 0, seo: 75 },
  { id: 6, title: 'Интеграция с Яндекс.Едой и Delivery Club', slug: 'integraciya-yandex-delivery', author: 'Екатерина Морозова', category: 'Интеграции', status: 'published' as Status, date: '15 июл 2026', views: 1890, seo: 91 },
]

const cases = [
  { id: 1, title: 'Додо Пицца: +42% выручки через Telegram-бот', company: 'Додо Пицца', city: 'Москва', status: 'published' as Status, date: '20 июл 2026', views: 3820, seo: 87 },
  { id: 2, title: 'Шоколадница: 18 000 участников программы лояльности', company: 'Шоколадница', city: 'Санкт-Петербург', status: 'published' as Status, date: '10 июл 2026', views: 2640, seo: 82 },
  { id: 3, title: 'Якитория Казань: рост онлайн-заказов в 3 раза', company: 'Якитория', city: 'Казань', status: 'draft' as Status, date: '—', views: 0, seo: 54 },
]

const newsItems = [
  { id: 1, title: 'Gastronavt запускает поддержку MAX-ботов', category: 'Продукт', status: 'published' as Status, date: '28 июл 2026', pinned: true },
  { id: 2, title: 'Мы вошли в топ-10 IT-компаний для ресторанного бизнеса', category: 'Компания', status: 'published' as Status, date: '20 июл 2026', pinned: false },
  { id: 3, title: 'Обновление CRM: новые отчёты и интеграции', category: 'Продукт', status: 'draft' as Status, date: '—', pinned: false },
]

const pages = [
  { id: 1, title: 'Главная', path: '/', status: 'published' as Status, seo: 88, edited: '30 июл 2026' },
  { id: 2, title: 'О компании', path: '/o-kompanii', status: 'published' as Status, seo: 72, edited: '25 июл 2026' },
  { id: 3, title: 'Продукты', path: '/products', status: 'published' as Status, seo: 91, edited: '28 июл 2026' },
  { id: 4, title: 'Цены', path: '/prices', status: 'published' as Status, seo: 85, edited: '20 июл 2026' },
  { id: 5, title: 'Контакты', path: '/contacts', status: 'published' as Status, seo: 68, edited: '18 июл 2026' },
  { id: 6, title: 'Интеграции', path: '/integracii', status: 'published' as Status, seo: 79, edited: '22 июл 2026' },
  { id: 7, title: 'Партнёры', path: '/partnery', status: 'draft' as Status, seo: 45, edited: '15 июл 2026' },
]

const statusCfg: Record<Status, { label: string; bg: string; text: string }> = {
  published: { label: 'Опубликовано', bg: 'bg-emerald-50', text: 'text-emerald-700' },
  draft: { label: 'Черновик', bg: 'bg-slate-100', text: 'text-slate-500' },
  scheduled: { label: 'Запланировано', bg: 'bg-cyan-50', text: 'text-cyan-700' },
}

const seoColor = (s: number) => s >= 80 ? 'text-emerald-600' : s >= 60 ? 'text-amber-500' : 'text-red-500'

function StatusChip({ status }: { status: Status }) {
  const c = statusCfg[status]
  return <span className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-md ${c.bg} ${c.text}`}>{c.label}</span>
}

// ── Editor ──────────────────────────────────────────────────────────────────

const checklistItems = [
  { label: 'Заголовок заполнен', state: 'ok' as const },
  { label: 'Краткое описание добавлено', state: 'ok' as const },
  { label: 'Обложка загружена', state: 'warn' as const },
  { label: 'Текст длиннее 800 слов', state: 'ok' as const },
  { label: 'Meta Title заполнен', state: 'ok' as const },
  { label: 'Meta Description заполнена', state: 'warn' as const },
  { label: 'Canonical URL задан', state: 'err' as const },
  { label: 'Категория выбрана', state: 'ok' as const },
]

function ToolbarBtn({ children, title }: { children: React.ReactNode; title?: string }) {
  return (
    <button title={title} className="px-2 h-7 text-xs font-medium text-slate-500 hover:bg-slate-200 hover:text-slate-800 rounded cursor-pointer transition-colors flex items-center gap-1">
      {children}
    </button>
  )
}

function SidebarLabel({ children }: { children: React.ReactNode }) {
  return <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">{children}</p>
}

function Editor({ onClose }: { onClose: () => void }) {
  const [title, setTitle] = useState('Как Telegram-бот увеличил выручку ресторана на 40%')
  const [indexing, setIndexing] = useState(true)
  const [status, setStatus] = useState<Status>('draft')

  const doneCount = checklistItems.filter(i => i.state === 'ok').length
  const pct = Math.round((doneCount / checklistItems.length) * 100)

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Top bar */}
      <div className="flex items-center justify-between px-6 py-3 bg-white border-b border-slate-200 flex-shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-700 cursor-pointer transition-colors">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
            Назад
          </button>
          <div className="w-px h-4 bg-slate-200" />
          <StatusChip status={status} />
          <span className="text-xs text-slate-400">Сохранено только что</span>
        </div>
        <div className="flex items-center gap-2">
          <button className="text-sm text-slate-500 hover:text-slate-700 border border-slate-200 rounded-lg px-3 py-1.5 cursor-pointer hover:bg-slate-50 transition-colors">Сохранить черновик</button>
          <button className="text-sm text-slate-500 hover:text-slate-700 border border-slate-200 rounded-lg px-3 py-1.5 cursor-pointer hover:bg-slate-50 transition-colors">Предпросмотр</button>
          <button className="text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 cursor-pointer transition-colors">Опубликовать</button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Main scrollable area */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-2xl mx-auto px-8 py-8 space-y-6">

            {/* 1. Basic Information */}
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
              <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Основная информация</h2>
              <input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Заголовок статьи..."
                className="w-full text-2xl font-bold text-slate-900 placeholder-slate-300 focus:outline-none bg-transparent leading-snug"
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField label="URL (slug)"><Input value="telegram-bot-vyruchka-40" /></FormField>
                <FormField label="Категория">
                  <Select value="bots" onChange={() => {}} options={[
                    { value: 'bots', label: 'Telegram-боты' },
                    { value: 'crm', label: 'CRM' },
                    { value: 'apps', label: 'Приложения' },
                    { value: 'loyalty', label: 'Лояльность' },
                  ]} className="w-full" />
                </FormField>
              </div>
              <FormField label="Краткое описание">
                <TextArea placeholder="Описание для превью и RSS-ленты..." rows={2} />
              </FormField>
            </div>

            {/* 2. Cover */}
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-3">
              <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Обложка</h2>
              <div className="relative rounded-xl overflow-hidden bg-gradient-to-br from-slate-100 to-slate-200 h-44 flex items-center justify-center group cursor-pointer border-2 border-dashed border-slate-200 hover:border-blue-400 transition-colors">
                <div className="text-center">
                  <div className="text-3xl mb-2">🖼</div>
                  <p className="text-sm text-slate-400">Перетащите файл или <span className="text-blue-600">выберите</span></p>
                  <p className="text-xs text-slate-300 mt-0.5">PNG, JPG, WebP · 1200×630px</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="text-xs border border-slate-200 text-slate-600 hover:bg-slate-50 px-3 py-1.5 rounded-lg cursor-pointer transition-colors">Заменить</button>
                <button className="text-xs border border-slate-200 text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg cursor-pointer transition-colors">Удалить</button>
              </div>
            </div>

            {/* 3. Content / RTE */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <div className="px-4 py-2.5 border-b border-slate-100 bg-slate-50">
                <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Текст статьи</h2>
                <div className="flex items-center gap-0.5 flex-wrap">
                  <ToolbarBtn title="Заголовок">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h8" /></svg>
                    H
                  </ToolbarBtn>
                  <div className="w-px h-4 bg-slate-300 mx-1" />
                  <ToolbarBtn title="Жирный"><strong>B</strong></ToolbarBtn>
                  <ToolbarBtn title="Курсив"><em>I</em></ToolbarBtn>
                  <ToolbarBtn title="Подчёркнутый"><span className="underline">U</span></ToolbarBtn>
                  <div className="w-px h-4 bg-slate-300 mx-1" />
                  <ToolbarBtn title="Список">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h16M4 18h16" /></svg>
                  </ToolbarBtn>
                  <ToolbarBtn title="Цитата">
                    <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/></svg>
                  </ToolbarBtn>
                  <ToolbarBtn title="Таблица">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>
                  </ToolbarBtn>
                  <div className="w-px h-4 bg-slate-300 mx-1" />
                  <ToolbarBtn title="Ссылка">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101"/><path strokeLinecap="round" strokeLinejoin="round" d="M14.828 14.828a4 4 0 015.656 0l-4 4a4 4 0 01-5.656-5.656l1.102-1.1"/></svg>
                  </ToolbarBtn>
                  <ToolbarBtn title="Изображение">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path strokeLinecap="round" strokeLinejoin="round" d="M21 15l-5-5L5 21"/></svg>
                  </ToolbarBtn>
                  <ToolbarBtn title="Видео">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.069A1 1 0 0121 8.82v6.36a1 1 0 01-1.447.89L15 14M4 8h7a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4a2 2 0 012-2z"/></svg>
                  </ToolbarBtn>
                  <ToolbarBtn title="Блок кода">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/></svg>
                  </ToolbarBtn>
                  <div className="w-px h-4 bg-slate-300 mx-1" />
                  <ToolbarBtn title="Отменить">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 10h10a8 8 0 018 8v2M3 10l6 6M3 10l6-6"/></svg>
                  </ToolbarBtn>
                  <ToolbarBtn title="Повторить">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 10H11a8 8 0 00-8 8v2M21 10l-6 6M21 10l-6-6"/></svg>
                  </ToolbarBtn>
                  <div className="w-px h-4 bg-slate-300 mx-1" />
                  <ToolbarBtn title="Предпросмотр">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                  </ToolbarBtn>
                </div>
              </div>
              <textarea
                className="w-full px-6 py-5 text-slate-700 text-sm leading-relaxed focus:outline-none resize-none font-sans"
                rows={18}
                defaultValue={"Telegram-боты стали мощным инструментом для ресторанного бизнеса. В этой статье мы разберём, как наши клиенты используют ботов для автоматизации заказов и увеличения выручки.\n\n## Почему рестораны выбирают Telegram\n\nАудитория Telegram в России превышает 80 миллионов активных пользователей. Для ресторана это означает прямой канал к клиентам без посредников и комиссий агрегаторов.\n\n## Кейс: сеть пиццерий «Берег»\n\nЗа три месяца после запуска бота выручка выросла на 40%, а средний чек увеличился на 18%."}
              />
            </div>

            {/* 4. SEO */}
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
              <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">SEO</h2>
              <FormField label="Meta Title" hint="50–60 символов">
                <Input value="Как Telegram-бот увеличил выручку ресторана на 40% | Gastronavt" />
              </FormField>
              <FormField label="Meta Description" hint="120–160 символов">
                <TextArea placeholder="Описание страницы для поисковых систем..." rows={3} />
              </FormField>
              <FormField label="OG Image" hint="1200×630px · изображение для соцсетей">
                <Input value="https://gastronavt.ru/images/og/telegram-bot.jpg" />
              </FormField>
              <FormField label="Canonical URL">
                <Input value="https://gastronavt.ru/blog/telegram-bot-vyruchka-40" />
              </FormField>

              {/* Indexing toggle */}
              <div className="flex items-center justify-between py-3 border-t border-slate-100">
                <div>
                  <p className="text-sm font-medium text-slate-700">Индексирование</p>
                  <p className="text-xs text-slate-400 mt-0.5">Разрешить поисковым системам индексировать страницу</p>
                </div>
                <button
                  onClick={() => setIndexing(v => !v)}
                  className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer flex-shrink-0 ${indexing ? 'bg-blue-600' : 'bg-slate-300'}`}
                >
                  <span className={`absolute top-0.5 h-4 w-4 bg-white rounded-full shadow transition-all ${indexing ? 'right-0.5' : 'left-0.5'}`} />
                </button>
              </div>

              {/* Search preview */}
              <div className="rounded-xl border border-slate-200 p-4 bg-slate-50">
                <p className="text-xs font-medium text-slate-400 mb-3">Превью в поиске</p>
                <div className="space-y-1">
                  <div className="text-xs text-emerald-700 font-mono">gastronavt.ru › blog › telegram-bot-vyruchka-40</div>
                  <div className="text-base text-blue-700 hover:underline cursor-pointer leading-snug">
                    Как Telegram-бот увеличил выручку ресторана на 40% | Gastronavt
                  </div>
                  <div className="text-sm text-slate-500 leading-relaxed">
                    Узнайте, как рестораны и кафе увеличивают выручку с помощью Telegram-ботов. Кейсы, цифры и практические советы от команды Gastronavt.
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Right sidebar */}
        <div className="w-60 border-l border-slate-200 bg-white overflow-y-auto flex-shrink-0 p-5 space-y-6">

          {/* Publication meta */}
          <div className="space-y-3">
            <SidebarLabel>Публикация</SidebarLabel>
            <div>
              <p className="text-xs text-slate-400 mb-1">Статус</p>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as Status)}
                className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-sm text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
              >
                <option value="draft">Черновик</option>
                <option value="scheduled">Запланировано</option>
                <option value="published">Опубликовано</option>
              </select>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-1">Дата публикации</p>
              <input type="date" defaultValue="2026-07-28" className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-1">Автор</p>
              <Select value="morozova" onChange={() => {}} options={[
                { value: 'morozova', label: 'Е. Морозова' },
                { value: 'kozlov', label: 'И. Козлов' },
                { value: 'sidorova', label: 'М. Сидорова' },
              ]} className="w-full" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-1">Категория</p>
              <Select value="bots" onChange={() => {}} options={[
                { value: 'bots', label: 'Telegram-боты' },
                { value: 'crm', label: 'CRM' },
                { value: 'apps', label: 'Приложения' },
              ]} className="w-full" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-1">Теги</p>
              <Input value="бот, выручка, кейс" className="w-full" />
            </div>
          </div>

          {/* Checklist */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <SidebarLabel>Готовность публикации</SidebarLabel>
            <div className="flex items-center justify-between mb-1">
              <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden mr-3">
                <div
                  className={`h-full rounded-full transition-all ${pct >= 80 ? 'bg-emerald-500' : pct >= 50 ? 'bg-amber-400' : 'bg-red-400'}`}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <span className={`text-xs font-bold flex-shrink-0 ${pct >= 80 ? 'text-emerald-600' : pct >= 50 ? 'text-amber-500' : 'text-red-500'}`}>{pct}%</span>
            </div>
            <div className="space-y-2">
              {checklistItems.map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold
                    ${item.state === 'ok' ? 'bg-emerald-100 text-emerald-600' : item.state === 'warn' ? 'bg-amber-100 text-amber-600' : 'bg-red-100 text-red-500'}`}>
                    {item.state === 'ok' ? '✓' : item.state === 'warn' ? '!' : '✕'}
                  </span>
                  <span className={item.state === 'ok' ? 'text-slate-600' : item.state === 'warn' ? 'text-amber-700' : 'text-slate-400'}>{item.label}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  )
}

// ── List views ───────────────────────────────────────────────────────────────

function ArticleList({ onEdit }: { onEdit: () => void }) {
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [selected, setSelected] = useState<number[]>([])

  const filtered = articles.filter(a => {
    if (search && !a.title.toLowerCase().includes(search.toLowerCase())) return false
    if (statusFilter !== 'all' && a.status !== statusFilter) return false
    return true
  })

  return (
    <>
      <div className="flex items-center gap-3 mb-5">
        <Input value={search} onChange={setSearch} placeholder="Поиск по статьям..." className="w-72"
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
        <Select value={statusFilter} onChange={setStatusFilter} options={[
          { value: 'all', label: 'Все статусы' },
          { value: 'published', label: 'Опубликованные' },
          { value: 'draft', label: 'Черновики' },
          { value: 'scheduled', label: 'Запланированные' },
        ]} />
        <Select value="all" onChange={() => {}} options={[
          { value: 'all', label: 'Все категории' },
          { value: 'bots', label: 'Telegram-боты' },
          { value: 'crm', label: 'CRM' },
        ]} />
        <div className="ml-auto">
          <button onClick={onEdit} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg cursor-pointer transition-colors">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
            Новая статья
          </button>
        </div>
      </div>

      {selected.length > 0 && (
        <div className="flex items-center gap-3 px-4 py-2.5 bg-blue-50 border border-blue-200 rounded-xl mb-4 text-sm">
          <span className="text-blue-700">Выбрано: {selected.length}</span>
          <button className="text-blue-600 hover:underline cursor-pointer">Опубликовать</button>
          <button className="text-red-500 hover:underline cursor-pointer">Удалить</button>
          <button onClick={() => setSelected([])} className="ml-auto text-blue-400 hover:text-blue-600 cursor-pointer">Сбросить</button>
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-4 py-3 text-left w-8">
                <input type="checkbox" className="rounded border-slate-300 cursor-pointer" onChange={e => setSelected(e.target.checked ? articles.map(a => a.id) : [])} />
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Заголовок</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Автор</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Статус</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Дата</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Просмотры</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">SEO</th>
              <th className="px-4 py-3 w-8" />
            </tr>
          </thead>
          <tbody>
            {filtered.map(a => (
              <tr key={a.id} className="border-t border-slate-100 hover:bg-slate-50 transition-colors group">
                <td className="px-4 py-3.5">
                  <input type="checkbox" checked={selected.includes(a.id)} onChange={() => setSelected(p => p.includes(a.id) ? p.filter(x => x !== a.id) : [...p, a.id])} className="rounded border-slate-300 cursor-pointer" />
                </td>
                <td className="px-4 py-3.5">
                  <div className="font-medium text-slate-900 hover:text-blue-600 cursor-pointer" onClick={onEdit}>{a.title}</div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">/{a.slug}</div>
                </td>
                <td className="px-4 py-3.5 text-slate-600">{a.author}</td>
                <td className="px-4 py-3.5"><StatusChip status={a.status} /></td>
                <td className="px-4 py-3.5 text-slate-500">{a.date}</td>
                <td className="px-4 py-3.5 text-right font-medium text-slate-800">{a.views > 0 ? a.views.toLocaleString('ru') : '—'}</td>
                <td className="px-4 py-3.5 text-right"><span className={`font-bold ${seoColor(a.seo)}`}>{a.seo}</span></td>
                <td className="px-4 py-3.5">
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={onEdit} className="p-1 text-slate-400 hover:text-blue-600 rounded cursor-pointer">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                    </button>
                    <button className="p-1 text-slate-400 hover:text-red-500 rounded cursor-pointer">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

function CaseList({ onEdit }: { onEdit: () => void }) {
  return (
    <>
      <div className="flex items-center gap-3 mb-5">
        <Input placeholder="Поиск по кейсам..." className="w-72"
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
        <div className="ml-auto">
          <button onClick={onEdit} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg cursor-pointer transition-colors">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
            Новый кейс
          </button>
        </div>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-5 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Кейс</th>
              <th className="px-5 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Компания</th>
              <th className="px-5 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Статус</th>
              <th className="px-5 py-3 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Просмотры</th>
              <th className="px-5 py-3 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">SEO</th>
              <th className="px-5 py-3 w-8" />
            </tr>
          </thead>
          <tbody>
            {cases.map(c => (
              <tr key={c.id} className="border-t border-slate-100 hover:bg-slate-50 transition-colors group">
                <td className="px-5 py-3.5">
                  <div className="font-medium text-slate-900 hover:text-blue-600 cursor-pointer" onClick={onEdit}>{c.title}</div>
                  <div className="text-xs text-slate-400 mt-0.5">{c.city}</div>
                </td>
                <td className="px-5 py-3.5 text-slate-600">{c.company}</td>
                <td className="px-5 py-3.5"><StatusChip status={c.status} /></td>
                <td className="px-5 py-3.5 text-right font-medium text-slate-800">{c.views > 0 ? c.views.toLocaleString('ru') : '—'}</td>
                <td className="px-5 py-3.5 text-right"><span className={`font-bold ${seoColor(c.seo)}`}>{c.seo}</span></td>
                <td className="px-5 py-3.5">
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={onEdit} className="p-1 text-slate-400 hover:text-blue-600 rounded cursor-pointer"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

function NewsList({ onEdit }: { onEdit: () => void }) {
  return (
    <>
      <div className="flex items-center gap-3 mb-5">
        <Input placeholder="Поиск по новостям..." className="w-72"
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
        <div className="ml-auto">
          <button onClick={onEdit} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg cursor-pointer transition-colors">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
            Новость
          </button>
        </div>
      </div>
      <div className="space-y-3">
        {newsItems.map(n => (
          <div key={n.id} className="bg-white rounded-xl border border-slate-200 px-5 py-4 flex items-center gap-4 hover:shadow-sm transition-shadow group cursor-pointer" onClick={onEdit}>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-medium text-slate-900">{n.title}</span>
                {n.pinned && <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded">📌 Закреплено</span>}
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-400">
                <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{n.category}</span>
                <span>{n.date}</span>
              </div>
            </div>
            <StatusChip status={n.status} />
            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="p-1 text-slate-400 hover:text-blue-600 rounded cursor-pointer"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg></button>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}

function PagesList({ onEdit }: { onEdit: () => void }) {
  return (
    <>
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-slate-500">{pages.length} страниц сайта</p>
        <button onClick={onEdit} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg cursor-pointer transition-colors">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
          Новая страница
        </button>
      </div>
      <div className="space-y-2">
        {pages.map(p => (
          <div key={p.id} className="bg-white rounded-xl border border-slate-200 px-5 py-4 flex items-center gap-5 hover:shadow-sm transition-shadow group">
            <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <svg className="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-slate-900">{p.title}</div>
              <div className="text-xs text-slate-400 font-mono">{p.path}</div>
            </div>
            <StatusChip status={p.status} />
            <div className="flex items-center gap-2 text-xs text-slate-400 flex-shrink-0">
              <span>SEO</span>
              <span className={`font-bold text-sm ${seoColor(p.seo)}`}>{p.seo}</span>
            </div>
            <span className="text-xs text-slate-400 flex-shrink-0">{p.edited}</span>
            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button onClick={onEdit} className="flex items-center gap-1 text-xs border border-slate-200 text-slate-600 hover:text-blue-600 hover:border-blue-200 px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors">Редактировать</button>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}

// ── Main component ───────────────────────────────────────────────────────────

export default function Content() {
  const [tab, setTab] = useState<ContentTab>('articles')
  const [editing, setEditing] = useState(false)

  if (editing) return <Editor onClose={() => setEditing(false)} />

  return (
    <div className="p-7 max-w-6xl mx-auto">
      {/* Tabs */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-1 border-b border-slate-200 -mb-px w-full">
          {tabDef.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-5 py-3 text-sm font-medium border-b-2 -mb-px transition-colors cursor-pointer ${tab === t.id ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === 'articles' && <ArticleList onEdit={() => setEditing(true)} />}
      {tab === 'cases' && <CaseList onEdit={() => setEditing(true)} />}
      {tab === 'news' && <NewsList onEdit={() => setEditing(true)} />}
      {tab === 'pages' && <PagesList onEdit={() => setEditing(true)} />}
    </div>
  )
}
